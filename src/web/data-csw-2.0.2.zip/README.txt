
Loading these records into the catalogue is a precondition for undergoing 
compliance testing. While the test data are represented as a set of csw:Record 
instances, no assumption is made about which application profile is supported 
by the implementation. It is expected that each profile defines a suitable 
mapping for ingesting csw:Record instances.
